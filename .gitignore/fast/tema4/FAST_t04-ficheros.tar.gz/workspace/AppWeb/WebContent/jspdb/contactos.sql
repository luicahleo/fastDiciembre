DROP TABLE contactos;
CREATE TABLE contactos(
num SERIAL,
nombre VARCHAR(20),
apellidos VARCHAR(20),
email VARCHAR(20),
telefono VARCHAR(10),
PRIMARY KEY (num));
