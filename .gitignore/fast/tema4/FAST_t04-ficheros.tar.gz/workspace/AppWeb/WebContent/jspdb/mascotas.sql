DROP TABLE mascotas;
CREATE TABLE mascotas( 
nombre VARCHAR(20), 
propietario VARCHAR(20), 
especie VARCHAR(20), 
sexo CHAR(1), 
nacimiento DATE, 
fallecimiento DATE,
PRIMARY KEY (nombre,propietario));
