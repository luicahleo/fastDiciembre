-- Table: SPJ
CREATE TABLE SPJ (
  ids INTEGER REFERENCES S (ids),
  idp INTEGER REFERENCES P (idp),
  idj INTEGER REFERENCES J (idj),
  cantidad INTEGER,
  PRIMARY KEY (ids, idp, idj)
);