-- Table: J
CREATE TABLE J (
  idj INTEGER,
  nomj CHAR(20) NOT NULL,
  ciudad CHAR(25) NOT NULL,
  PRIMARY KEY (idj)
);