-- Table: P
CREATE TABLE P (
  idp INTEGER,
  nomp CHAR(20) NOT NULL,
  color CHAR(10) NOT NULL,
  peso INTEGER NOT NULL,
  ciudad CHAR(25) NOT NULL,
  PRIMARY KEY (idp)
);