-- borra las tablas
drop table spj;
drop table s;
drop table p;
drop table j;
-- crea las tablas
\i s.sql
\i p.sql
\i j.sql
\i spj.sql
-- carga las tablas
\copy s from s.txt
\copy s from s_solo01.txt
\copy p from p.txt
\copy j from j.txt
\copy spj from spj.txt
-- muestra las tablas
select * from s;
select * from p;
select * from j;
select * from spj;
