
-- Obtener los nombres de los proyectos en los que el suministrador es “1”.

SELECT DISTINCT nomj FROM j,spj WHERE spj.idj = j.idj AND spj.ids ='1' ORDER BY nomj;

SELECT nomj FROM j WHERE idj IN (SELECT idj FROM spj WHERE ids ='1') ORDER BY nomj;

