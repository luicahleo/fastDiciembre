-- Table: usuarios
CREATE TABLE usuarios ( 
 name CHAR(20) NOT NULL, 
 password CHAR(20) NOT NULL, 
 PRIMARY KEY (name) 
); 
INSERT INTO usuarios (name,password) VALUES ('user1', 'pass1');
INSERT INTO usuarios (name,password) VALUES ('user2', 'pass2');
SELECT * FROM usuarios;
