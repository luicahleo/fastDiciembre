-- Table: S
CREATE TABLE S (
  ids INTEGER,
  noms CHAR(20) NOT NULL,
  estado CHAR(25),
  ciudad CHAR(25) NOT NULL,
  PRIMARY KEY (ids)
);